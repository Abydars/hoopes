<?php
namespace Ari_Adminer\Models;

use Ari\Models\Model as Model;

class Settings extends Model {}
